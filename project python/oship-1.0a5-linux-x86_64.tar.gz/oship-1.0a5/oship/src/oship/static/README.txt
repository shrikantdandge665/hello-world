Put static files here, like javascript and css.  They will be
available as static/<filename> in views.
